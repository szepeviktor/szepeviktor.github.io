Don't worry the small version number of this package. It's just working
and so I did not have to write any updates to it yet. Most of the work is
just done in libsrs2 which is used by this package. Therefore I did not have
to do much to get it working.

2007-09-21 Matthias Wimmer

## Note on version 0.1.2

This version has no functional differences. It just includes a small change
in the build script. So no need to update.

2009-10-11 Matthias Wimmer
