#
#   tkdialog.rb - load tk/dialog.rb
#
require 'tk/dialog'
