#
#  setup.rb   --   setup script before using Tk extension libraries
#
#    If you need some setup operations for Tk extensions (for example,
#    modify the dynamic library path) required, please write the setup
#    operations in this file. This file is required at the last of
#    "require 'tk'".
#
