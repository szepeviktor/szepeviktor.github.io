var searchData=
[
  ['uptime',['uptime',['../structapr__memcache__stats__t.html#aec6db8440a51aabfbfaf2130ec5a78bb',1,'apr_memcache_stats_t']]],
  ['user',['user',['../structapr__uri__t.html#a2b763f50bec4fda0cf67e5238275b5fd',1,'apr_uri_t']]]
];
