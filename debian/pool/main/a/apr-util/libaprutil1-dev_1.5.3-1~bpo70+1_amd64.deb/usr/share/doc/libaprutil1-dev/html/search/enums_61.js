var searchData=
[
  ['apr_5fdbd_5ftype_5fe',['apr_dbd_type_e',['../group___a_p_r___util___d_b_d.html#ga19608fa5d518a5121bee23daacc5c230',1,'apr_dbd.h']]],
  ['apr_5fmemcache_5fserver_5fstatus_5ft',['apr_memcache_server_status_t',['../group___a_p_r___util___m_c.html#ga3b18c7c3f0ecabb930b78aa549c2e2e8',1,'apr_memcache.h']]],
  ['apr_5fread_5ftype_5fe',['apr_read_type_e',['../group___a_p_r___util___bucket___brigades.html#ga756973fb6392bd1026c3d96b4519776d',1,'apr_buckets.h']]]
];
