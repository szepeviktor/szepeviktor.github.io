var searchData=
[
  ['data',['data',['../structapr__bucket.html#a7fc4604750889b3f762bda1a786d276a',1,'apr_bucket::data()'],['../structapr__sha1__ctx__t.html#af61fc6c30be244247e35e7c8b0b63407',1,'apr_sha1_ctx_t::data()'],['../structapr__uuid__t.html#a8e3dadfe1bd9cbf26478127c4110e0d0',1,'apr_uuid_t::data()']]],
  ['datum_5fget',['datum_get',['../structapr__dbd__driver__t.html#a67ff50c786b46c305936c6593a6c5959',1,'apr_dbd_driver_t']]],
  ['del',['del',['../structapr__dbm__type__t.html#a06d2f0a91b5ea931996acf364f392073',1,'apr_dbm_type_t']]],
  ['destroy',['destroy',['../structapr__bucket__type__t.html#aa5a8ae7611ba3be480e3fd12ff3ac352',1,'apr_bucket_type_t']]],
  ['digest',['digest',['../structapr__sha1__ctx__t.html#a152a127b59eb6e1cb686c2bbe00d51de',1,'apr_sha1_ctx_t']]],
  ['dns_5flooked_5fup',['dns_looked_up',['../structapr__uri__t.html#ae28c03382cb6fcb226dfc76193699342',1,'apr_uri_t']]],
  ['dns_5fresolved',['dns_resolved',['../structapr__uri__t.html#a805976fea6ef65f3ec1185c7d6dcf7f3',1,'apr_uri_t']]],
  ['dptr',['dptr',['../structapr__datum__t.html#a7f4e0997f26d818c5674446ebb3d58bb',1,'apr_datum_t::dptr()'],['../structapr__sdbm__datum__t.html#a927c668d3912a4cc8466b0f551d00169',1,'apr_sdbm_datum_t::dptr()']]],
  ['dsize',['dsize',['../structapr__datum__t.html#a5b58c23a5f65a8a6e3f8228fef5e429c',1,'apr_datum_t::dsize()'],['../structapr__sdbm__datum__t.html#aedbd0295ba540695d5b407f1dec90eb5',1,'apr_sdbm_datum_t::dsize()']]]
];
