var searchData=
[
  ['sdbm_20library',['SDBM library',['../group___a_p_r___util___d_b_m___s_d_b_m.html',1,'']]],
  ['string_20matching_20routines',['String matching routines',['../group___a_p_r___util___str_match.html',1,'']]],
  ['status_20value_20tests',['Status Value Tests',['../group___a_p_u___s_t_a_t_u_s___i_s.html',1,'']]],
  ['scheme',['scheme',['../structapr__uri__t.html#a5d62fa370265b6bc956aa86d36024a5d',1,'apr_uri_t']]],
  ['select',['select',['../structapr__dbd__driver__t.html#adc4a483ffb93e88532034a25600ab1e4',1,'apr_dbd_driver_t']]],
  ['set_5fdbname',['set_dbname',['../structapr__dbd__driver__t.html#a5ec15b2e1c4f2cee690d09c14fef689b',1,'apr_dbd_driver_t']]],
  ['setaside',['setaside',['../structapr__bucket__type__t.html#a4e2015fd6e927ed55157a9b003ed5fdb',1,'apr_bucket_type_t']]],
  ['split',['split',['../structapr__bucket__type__t.html#af30959bc15fc60e21224d5e3c8c0a814',1,'apr_bucket_type_t']]],
  ['start',['start',['../structapr__bucket.html#a4a8791b606b3ad613b8672ec94145628',1,'apr_bucket']]],
  ['start_5ftransaction',['start_transaction',['../structapr__dbd__driver__t.html#ad1a4117f436e9fb54e75922a0b21541e',1,'apr_dbd_driver_t']]],
  ['state',['state',['../structapr__md4__ctx__t.html#a7fc20af590cdf6d01208a12ac0bbc5de',1,'apr_md4_ctx_t::state()'],['../structapr__md5__ctx__t.html#ab8acbc6cd7a3dcd16e66e64a7f5357b5',1,'apr_md5_ctx_t::state()']]],
  ['status',['status',['../structapr__memcache__server__t.html#a641c9cd95499a998ba2717ec5f03b174',1,'apr_memcache_server_t']]],
  ['store',['store',['../structapr__dbm__type__t.html#ae156d00ff445fbe6472565165f7e746c',1,'apr_dbm_type_t']]]
];
