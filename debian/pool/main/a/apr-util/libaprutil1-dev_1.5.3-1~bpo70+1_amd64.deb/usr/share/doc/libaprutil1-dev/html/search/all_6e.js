var searchData=
[
  ['nalloc',['nalloc',['../structapr__memcache__t.html#a95d15cfa5b291700cd9a697687eeac73',1,'apr_memcache_t']]],
  ['name',['name',['../structapr__bucket__type__t.html#ac6d779be45de214c6abd2cc205c48901',1,'apr_bucket_type_t::name()'],['../structapr__xml__attr.html#a2ac25d74e3fd8a521b70af15ae8c1257',1,'apr_xml_attr::name()'],['../structapr__xml__elem.html#a5b2fb684a9cfb244f88ad88f539fe3d6',1,'apr_xml_elem::name()'],['../structapr__dbd__driver__t.html#a5483b4c47dde6814395bebfb7959fb37',1,'apr_dbd_driver_t::name()'],['../structapr__dbm__type__t.html#af023b97eba22415785caf005fc5dcf64',1,'apr_dbm_type_t::name()']]],
  ['namespaces',['namespaces',['../structapr__xml__doc.html#a6aee4d0e4516c9b8191ad734c2748d39',1,'apr_xml_doc']]],
  ['native_5fhandle',['native_handle',['../structapr__dbd__driver__t.html#a435f098bde2b17e3b156ef33d0c9c37e',1,'apr_dbd_driver_t']]],
  ['next',['next',['../structapr__text.html#aaf1b48e3f3085522fe7355e7d8893111',1,'apr_text::next()'],['../structapr__xml__attr.html#a89a314d3136128eb2a37146ddb30da4f',1,'apr_xml_attr::next()'],['../structapr__xml__elem.html#a8687253d504b1c1363c47117611042ac',1,'apr_xml_elem::next()']]],
  ['nextkey',['nextkey',['../structapr__dbm__type__t.html#ace0c5f3bc24df10170b4031b48fd9af0',1,'apr_dbm_type_t']]],
  ['ns',['ns',['../structapr__xml__attr.html#ad08daf8b0b47796aae04b6aeaa332bc2',1,'apr_xml_attr::ns()'],['../structapr__xml__elem.html#a613ea31964572df7b41f5a9da8d0982e',1,'apr_xml_elem::ns()']]],
  ['ns_5fscope',['ns_scope',['../structapr__xml__elem.html#addfd70c22965dca4f7574639424a0c32',1,'apr_xml_elem']]],
  ['ntotal',['ntotal',['../structapr__memcache__t.html#a94e1353d23d4d02a18a9f0ca0e90005d',1,'apr_memcache_t']]],
  ['num_5fcols',['num_cols',['../structapr__dbd__driver__t.html#ab71099e0877a99b7743f70b927f44353',1,'apr_dbd_driver_t']]],
  ['num_5ffunc',['num_func',['../structapr__bucket__type__t.html#ad4bd2ffb03cb2f5f3b3941ce20468038',1,'apr_bucket_type_t']]],
  ['num_5ftuples',['num_tuples',['../structapr__dbd__driver__t.html#a8e307da83a358c169706ea9154f58f22',1,'apr_dbd_driver_t']]]
];
